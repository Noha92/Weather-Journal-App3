// Setup empty JS object to act as endpoint for all routes
projectData = {};

// Require Express to run server and routes
const express = require('express');

// Start up an instance of app
const app = express();
/* Dependencies */
const bodyParser = require('body-parser');

/* Middleware*/
//Here we are configuring express to use body-parser as middle-ware.
app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());

// Cors for cross origin allowance
const cors = require('cors');
app.use(cors());

// Initialize the main project folder
app.use(express.static('website'));
const port = 4800;

//get all data
app.get('/projectData', (req, res) => {
  // Send projectData as response
  res.status(200).send(projectData).end();
});
// post data 
app.post('/projectData', (req, res) => {
    // saving the data in the variable
    projectData = {
      date: req.body.date,
      temp: req.body.temp,
      content: req.body.content
    };
response.send(projectData).status(200).end();
    // console.log(projectData);
    // res.status(200).send({
    //   sucess: true,
    //   message: "Data saved successfully",
    //   data: projectData
    });


// Setup Server
app.listen(port,  () => {
  console.log(`Server running on http://localhost:${port}`);
});

