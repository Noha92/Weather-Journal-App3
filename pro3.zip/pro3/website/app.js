// Personal API Key for OpenWeatherMap API
const apiKey ='&appid=35035ba46b4539df85af2c6325b69bcb&units=metric';

// Creating a new date instance dynamically with JS
let d = new Date();
let newDate = d.getMonth()+'.'+ d.getDate()+'.'+ d.getFullYear();


// Global Variables 
let baseURL = 'http://api.openweathermap.org/data/2.5/weather?zip=';
const error = document.getElementById("error");
const server = " http://localhost:4800";






document.getElementById('generate').addEventListener('click', generateData);

function generateData(e){
  const zip =  document.getElementById('zip').value;
  const feelings = document.getElementById('feelings').value;
  console.log(baseURL+zip+apiKey)
  const getTemp = async (baseURL,temperature,apiKey)=>{
      
      const res = await fetch(baseURL+temperature+apiKey)
    try {

    const data=await res.json();
    return data;
    
    }  catch(error) {
    console.log("error", error);
    
     }
    }
   getTemp(baseURL,zip,apiKey).then( res =>{ console.log(res);
    
      
    
   
    postData('/add', {zip: zip, date: newDate, feelings: feelings});
    retrieveData();
  }
   
   )}


/* Function to GET Web API Data*/
const getWeatherData = async (zip) => {
  try {
    const res = await fetch(baseURL + zip + apiKey);
    const data = await res.json();

    if (data.cod != 200) {
      // display the error message on UI
      error.innerHTML = data.message;
      setTimeout(_=> error.innerHTML = '', 2000)
      throw `${data.message}`;
    }

    return data;
  } catch (error) {
    console.log(error);
  }
};


/* Function to POST data */
const postData = async (url = "", info = {}) => {
  const res = await fetch(url, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify(info),
  });

  try {
    const newData = await res.json();
    console.log(`You just saved`, newData);
    return newData;
  } catch (error) {
    console.log(error);
  }
};



/* Function to GET Project Data */
const retrieveData = async () => {
  const res = await fetch(server + "/all");
  try {
    const savedData = await res.json();

    document.getElementById("date").innerHTML = savedData.newDate;
    document.getElementById("city").innerHTML = savedData.city;
    document.getElementById("temp").innerHTML = savedData.temp + '&degC';
    document.getElementById("description").innerHTML = savedData.description;
    document.getElementById("content").innerHTML = savedData.feelings;
  } catch (error) {
    console.log(error);
  }
};
